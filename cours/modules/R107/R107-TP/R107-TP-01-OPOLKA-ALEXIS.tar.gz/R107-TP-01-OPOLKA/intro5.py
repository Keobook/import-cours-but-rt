#!/usr/bin/python3

from os import system

## Clean std::out
system("clear")

## On joue avec les variables
x = "Hello World, It's me RT1"
print(x)